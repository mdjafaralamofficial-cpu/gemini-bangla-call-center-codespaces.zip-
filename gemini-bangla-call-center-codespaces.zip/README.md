# Gemini Bangla Incoming Call — Codespaces Starter

A runnable starter for connecting a Twilio incoming voice call to Google Gemini Live API.

**Prototype only:** not production-ready. It does not yet implement Twilio signature validation, robust interruption/barge-in, order database integration, human-agent transfer, call recording consent, or production-grade recovery.

## Included
- FastAPI server and mobile-friendly status page
- `/health` health check
- `/voice` Twilio incoming-call webhook
- `/media` Twilio Media Streams WebSocket connected to Gemini Live
- Bengali sales-agent prompt
- Environment template

## 1. Open in GitHub Codespaces
Upload these files to a new GitHub repository, or put them in your fork of `microsoft/call-center-ai`. Open **Code → Codespaces → Create codespace**.

This package is a separate integration starter; it does not overwrite Microsoft's files.

## 2. Install
```bash
python -m pip install -r requirements.txt
cp .env.example .env
```
Edit `.env`. Get a key at https://aistudio.google.com/apikey. Check current Live API model names at https://ai.google.dev/gemini-api/docs/live-api; do not guess the model name.

## 3. Run
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open the Codespaces **Ports** tab and open port 8000. `/health` should return JSON.

For Twilio to reach the server, set port visibility to **Public** only while testing. Copy its HTTPS URL, e.g. `https://YOUR-CODESPACE-8000.app.github.dev`, set `PUBLIC_BASE_URL` to that exact URL (no trailing slash), then restart Uvicorn.

## 4. Configure Twilio
You need a Twilio voice number/account or another compatible telephony provider. Check Bangladesh number availability and pricing with the provider.

Set the incoming-call Voice webhook to:
`https://YOUR-CODESPACE-URL/voice`
Method: `POST`.

Call the configured number and inspect Codespaces terminal logs.

## Environment variables
```dotenv
GEMINI_API_KEY=put_your_google_ai_studio_key_here
GEMINI_LIVE_MODEL=put_current_supported_live_audio_model_here
PUBLIC_BASE_URL=https://your-codespace-forwarded-url
HOST=0.0.0.0
PORT=8000
```

Never commit `.env`; keep the API key on the server.

## Troubleshooting
- Missing key: check `.env`, restart Uvicorn.
- Model unsupported: check current Live API model list and account access.
- Twilio cannot connect: make sure port 8000 is Public during testing and URL is correct.
- No/distorted audio: phone audio is 8 kHz G.711 μ-law while Gemini Live uses PCM; conversions are included but API behavior can change.
- Check terminal logs for call errors.

## Before production
Add Twilio request-signature validation; barge-in/output-buffer clearing; robust audio buffering and reconnection; rate limits; secure secret management; human fallback; privacy/consent notices; monitoring; and product/order database tools. Never claim an order/payment succeeded without a trusted backend confirmation.
