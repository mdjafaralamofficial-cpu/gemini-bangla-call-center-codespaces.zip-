import os
import json
import base64
import asyncio
import logging
from pathlib import Path
from contextlib import suppress
from urllib.parse import urlparse

from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, Response, JSONResponse
from google import genai
from google.genai import types

try:
    import audioop
except ImportError:
    import audioop  # supplied by audioop-lts on Python 3.13+

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("gemini-bangla-call")

API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MODEL = os.getenv("GEMINI_LIVE_MODEL", "").strip()
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").strip().rstrip("/")
SYSTEM_PROMPT = Path(__file__).with_name("prompt.txt").read_text(encoding="utf-8")

app = FastAPI(title="Gemini Bangla Incoming Call Starter")
client = genai.Client(api_key=API_KEY) if API_KEY else None


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "gemini_key_configured": bool(API_KEY),
        "live_model_configured": bool(MODEL),
        "public_url_configured": bool(PUBLIC_BASE_URL),
    }


@app.get("/", response_class=HTMLResponse)
async def home():
    return HTMLResponse("""<!doctype html>
<html lang="bn"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>বাংলা AI Call Center</title>
<style>
body{font-family:system-ui,sans-serif;max-width:760px;margin:30px auto;padding:0 16px;line-height:1.55;color:#172033}
.card{border:1px solid #d8dee9;border-radius:14px;padding:16px;margin:14px 0}
code{overflow-wrap:anywhere;background:#f2f4f7;padding:3px}
a{overflow-wrap:anywhere}li{margin:8px 0}.note{color:#5c6575}
</style></head><body>
<h1>বাংলা AI Incoming Call</h1>
<p>সার্ভার চালু আছে। এই পেজটি সেটআপ ও health-check-এর জন্য। ফোন কল পরীক্ষা করতে নিচের ধাপগুলো অনুসরণ করুন।</p>
<div class="card"><h2>পরীক্ষার ঠিকানা</h2>
<p><a href="/health">/health — সার্ভারের অবস্থা</a></p>
<p><code>/voice</code> — Twilio incoming-call webhook</p>
<p><code>/media</code> — Twilio bidirectional media WebSocket</p></div>
<div class="card"><h2>পরের ধাপ</h2><ol>
<li><code>.env</code> ফাইলে Gemini API key ও সমর্থিত Live model দিন।</li>
<li>Codespaces-এর Ports ট্যাবে 8000 port Public করুন (শুধু পরীক্ষার সময়)।</li>
<li><code>PUBLIC_BASE_URL</code>-এ forwarded HTTPS URL বসিয়ে সার্ভার restart করুন।</li>
<li>Twilio Voice webhook-এ <code>/voice</code> URL সেট করুন।</li>
</ol></div>
<p class="note">সতর্কতা: এটি পরীক্ষামূলক starter, production-ready call-center নয়। API key কখনো browser-এ দেবেন না বা GitHub-এ commit করবেন না।</p>
</body></html>""")


@app.api_route("/voice", methods=["GET", "POST"])
async def incoming_call():
    if not PUBLIC_BASE_URL:
        return JSONResponse({"error": "PUBLIC_BASE_URL is missing in .env"}, status_code=500)
    if not API_KEY or not MODEL:
        return JSONResponse({"error": "Set GEMINI_API_KEY and GEMINI_LIVE_MODEL in .env"}, status_code=500)

    parsed = urlparse(PUBLIC_BASE_URL)
    if parsed.scheme != "https" or not parsed.netloc:
        return JSONResponse({"error": "PUBLIC_BASE_URL must be the HTTPS Codespaces URL"}, status_code=500)

    stream_url = "wss://" + parsed.netloc + "/media"
    twiml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="{stream_url}" />
  </Connect>
</Response>"""
    return Response(content=twiml, media_type="application/xml")


@app.websocket("/media")
async def media_stream(ws: WebSocket):
    await ws.accept()
    if client is None or not MODEL:
        await ws.close(code=1011, reason="Gemini environment not configured")
        return

    stream_sid = None
    stop_event = asyncio.Event()
    output_task = None

    try:
        async with client.aio.live.connect(
            model=MODEL,
            config=types.LiveConnectConfig(
                response_modalities=["AUDIO"],
                system_instruction=SYSTEM_PROMPT,
            ),
        ) as session:

            async def gemini_to_twilio():
                nonlocal stream_sid
                rate_state = None
                try:
                    async for response in session.receive():
                        if stop_event.is_set():
                            break
                        data = getattr(response, "data", None)
                        if not data:
                            continue
                        pcm8, rate_state = audioop.ratecv(data, 2, 1, 24000, 8000, rate_state)
                        mulaw = audioop.lin2ulaw(pcm8, 2)
                        for offset in range(0, len(mulaw), 160):
                            if stop_event.is_set() or not stream_sid:
                                break
                            chunk = mulaw[offset:offset + 160]
                            if chunk:
                                await ws.send_json({
                                    "event": "media",
                                    "streamSid": stream_sid,
                                    "media": {"payload": base64.b64encode(chunk).decode("ascii")},
                                })
                except asyncio.CancelledError:
                    raise
                except Exception:
                    log.exception("Gemini receive/output failed")
                    stop_event.set()

            output_task = asyncio.create_task(gemini_to_twilio())

            while not stop_event.is_set():
                event = json.loads(await ws.receive_text())
                event_type = event.get("event")

                if event_type == "connected":
                    log.info("Twilio media stream connected")
                elif event_type == "start":
                    stream_sid = event.get("start", {}).get("streamSid")
                    log.info("Call stream started: %s", stream_sid)
                elif event_type == "media":
                    payload = event.get("media", {}).get("payload")
                    if not payload:
                        continue
                    mulaw = base64.b64decode(payload)
                    pcm8 = audioop.ulaw2lin(mulaw, 2)
                    pcm16, _ = audioop.ratecv(pcm8, 2, 1, 8000, 16000, None)
                    await session.send_realtime_input(
                        audio=types.Blob(data=pcm16, mime_type="audio/pcm;rate=16000")
                    )
                elif event_type == "stop":
                    log.info("Twilio stream stopped")
                    break

    except WebSocketDisconnect:
        log.info("Twilio WebSocket disconnected")
    except asyncio.CancelledError:
        raise
    except Exception:
        log.exception("Call session failed")
    finally:
        stop_event.set()
        if output_task is not None:
            output_task.cancel()
            with suppress(Exception, asyncio.CancelledError):
                await output_task
        with suppress(Exception):
            await ws.close()
